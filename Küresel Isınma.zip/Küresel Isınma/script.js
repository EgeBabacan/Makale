// Okuma ilerlemesini, tema dugmesini ve telif yilini yonetir.
const ilerlemeCubugu = document.querySelector("#ilerleme-cubugu");
const temaDugmesi = document.querySelector("#tema-degistir");
const guncelYil = document.querySelector("#guncel-yil");
const gezinmeBaglantilari = [...document.querySelectorAll("nav a")];
const bolumler = gezinmeBaglantilari
  .map((link) => document.querySelector(link.getAttribute("href")))
  .filter(Boolean);
let bekleyenBolumKimligi = null;

// Sayfa asagi kaydirildikca makalenin ne kadar okundugunu hesaplar.
function okumaIlerlemesiniGuncelle() {
  const sayfaYuksekligi = document.documentElement.scrollHeight - window.innerHeight;
  const ilerleme = sayfaYuksekligi > 0 ? (window.scrollY / sayfaYuksekligi) * 100 : 0;

  ilerlemeCubugu.style.width = `${Math.min(ilerleme, 100)}%`;
}

// Kullanici tercih ettigi gorunumu tarayicida hatirlar.
function temayiGuncelle(tema) {
  const geceMi = tema === "gece";

  document.body.classList.toggle("gece-temasi", geceMi);
  temaDugmesi.textContent = geceMi ? "Gunduz gorunumu" : "Gece gorunumu";
  temaDugmesi.setAttribute("aria-pressed", String(geceMi));
  localStorage.setItem("site-tema", tema);
}

// Tema dugmesine basildiginda acik ve koyu gorunum arasinda gecis yapar.
function temayiDegistir() {
  const sonrakiTema = document.body.classList.contains("gece-temasi") ? "gunduz" : "gece";

  temayiGuncelle(sonrakiTema);
}

// Sayfadaki konumuna gore dogru makale bolumunu menude vurgular.
function aktifBolumuGuncelle() {
  const baslik = document.querySelector("header");
  const etkinlikCizgisi = (baslik?.getBoundingClientRect().bottom || 0) + 24;

  // Yeni bir baglantiya tiklanmissa yumusak kaydirma bitene kadar secimi korur.
  if (bekleyenBolumKimligi) {
    const bekleyenSira = bolumler.findIndex((bolum) => bolum.id === bekleyenBolumKimligi);
    const bekleyenBolum = bolumler[bekleyenSira];
    const sonrakiBolum = bolumler[bekleyenSira + 1];
    const hedefeUlasildi = bekleyenBolum.getBoundingClientRect().top <= etkinlikCizgisi
      && (!sonrakiBolum || sonrakiBolum.getBoundingClientRect().top > etkinlikCizgisi);

    if (!hedefeUlasildi) {
      return;
    }

    bekleyenBolumKimligi = null;
  }

  let aktifBolum = bolumler[0];

  bolumler.forEach((bolum) => {
    if (bolum.getBoundingClientRect().top <= etkinlikCizgisi) {
      aktifBolum = bolum;
    }
  });

  gezinmeBaglantilari.forEach((link) => {
    link.classList.toggle("aktif", link.getAttribute("href") === `#${aktifBolum.id}`);
  });
}

// Icerigi ekrana girerken yumusak bir gorunme animasyonu uygular.
function icerigiGorunurYap() {
  const gorunmeItems = document.querySelectorAll("article > *");
  const gorunmeObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) {
        return;
      }

      entry.target.classList.add("gorunur");
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.12 });

  gorunmeItems.forEach((oge) => {
    oge.classList.add("gorunme");
    gorunmeObserver.observe(oge);
  });
}

// Dugmeye basildiginda kisa bir dalga efekti olusturur.
function dalgaOlustur(olay) {
  const dalga = document.createElement("span");
  const dugmeSinirlari = temaDugmesi.getBoundingClientRect();
  const cap = Math.max(dugmeSinirlari.width, dugmeSinirlari.height);

  dalga.className = "dalga";
  dalga.style.width = `${cap}px`;
  dalga.style.height = `${cap}px`;
  dalga.style.left = `${olay.clientX - dugmeSinirlari.left - cap / 2}px`;
  dalga.style.top = `${olay.clientY - dugmeSinirlari.top - cap / 2}px`;
  temaDugmesi.appendChild(dalga);
  dalga.addEventListener("animationend", () => dalga.remove());
}

// Sayfada guncel yili otomatik olarak gosterir.
guncelYil.textContent = new Date().getFullYear();

// Daha once kaydedilmis tema tercihini uygular.
temayiGuncelle(localStorage.getItem("site-tema") || "gunduz");
temaDugmesi.addEventListener("click", temayiDegistir);
temaDugmesi.addEventListener("click", dalgaOlustur);
gezinmeBaglantilari.forEach((link) => {
  link.addEventListener("click", () => {
    bekleyenBolumKimligi = link.getAttribute("href").slice(1);
    gezinmeBaglantilari.forEach((oge) => oge.classList.remove("aktif"));
    link.classList.add("aktif");
  });
});
window.addEventListener("scroll", okumaIlerlemesiniGuncelle, { passive: true });
window.addEventListener("scroll", aktifBolumuGuncelle, { passive: true });
okumaIlerlemesiniGuncelle();
aktifBolumuGuncelle();
icerigiGorunurYap();


